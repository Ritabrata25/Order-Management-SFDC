import {LightningElement,api} from 'lwc';
    import getRelatedList from '@salesforce/apex/RelatedListController.getRelatedList';
    export default class View extends LightningElement {
        @api recordId;
        @api objectApiName;
        relProductsList = [];
        selects;
    
        connectedCallback() {
                getRelatedList({
                    orderId: this.recordId
                })
                .then(result => {
                    console.log(JSON.parse(result));
                    this.relProductsList = JSON.parse(result);
                })
                .catch(error => {
                    console.log(error);
                });
        }
    }