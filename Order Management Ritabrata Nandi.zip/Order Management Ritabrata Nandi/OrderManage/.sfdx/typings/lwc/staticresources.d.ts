declare module "@salesforce/resourceUrl/orderBack" {
    var orderBack: string;
    export default orderBack;
}
